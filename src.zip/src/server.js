const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const QRCode = require('qrcode');
const os = require('os');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Configuração do multer para armazenar arquivos
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/'); // Pasta onde os arquivos serão armazenados
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname); // Nome original do arquivo
    }
});

const upload = multer({ storage: storage });

// Middleware para servir arquivos estáticos
app.use('/uploads', express.static('uploads'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); // Para lidar com JSON

// Variável para armazenar textos compartilhados
let sharedTexts = [];

// Rota para upload de arquivos
app.post('/upload', upload.array('files'), (req, res) => {
    const targetFolder = req.body.targetFolder || '';
    const uploadPath = path.join(__dirname, 'uploads', targetFolder);

    if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
    }

    req.files.forEach(file => {
        const oldPath = path.join(__dirname, 'uploads', file.originalname);
        const newPath = path.join(uploadPath, file.originalname);
        fs.renameSync(oldPath, newPath);
    });

    res.send('Arquivos enviados com sucesso!');
});

// Rota para listar arquivos na pasta uploads
app.get('/uploads', (req, res) => {
    fs.readdir('uploads', { withFileTypes: true }, (err, files) => {
        if (err) {
            return res.status(500).send('Erro ao listar arquivos.');
        }
        let fileLinks = files.map(file => {
            const filePath = path.join('uploads', file.name);
            return file.isDirectory() 
                ? `<li style="color: green;"><a href="/uploads/${file.name}" style="color: green;">${file.name}</a></li>` 
                : `<li><a href="/uploads/${file.name}">${file.name}</a></li>`;
        }).join('');
        res.send(`
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Arquivos Disponíveis</title>
                <style>
                    li {
                        list-style-type: disc; /* Define o estilo da bolinha */
                    }
                    li a {
                        text-decoration: none; /* Remove o sublinhado dos links */
                    }
                </style>
            </head>
            <body>
                <h1>Arquivos Disponíveis</h1>
                <a href="/">Voltar para o upload</a>
                <ul>${fileLinks}</ul>
            </body>
            </html>
        `);
    });
});

// Rota para listar arquivos em uma subpasta
app.get('/uploads/:folder', (req, res) => {
    const folderPath = path.join('uploads', req.params.folder);
    fs.readdir(folderPath, { withFileTypes: true }, (err, files) => {
        if (err) {
            return res.status(500).send('Erro ao listar arquivos.');
        }
        let fileLinks = files.map(file => {
            const filePath = path.join(req.params.folder, file.name);
            return file.isDirectory() 
                ? `<li style="color: green;"><a href="/uploads/${filePath}" style="color: green;">${file.name}</a></li>` 
                : `<li><a href="/uploads/${filePath}">${file.name}</a></li>`;
        }).join('');
        res.send(`
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Arquivos Disponíveis</title>
                <style>
                    li {
                        list-style-type: disc; /* Define o estilo da bolinha */
                    }
                    li a {
                        text-decoration: none; /* Remove o sublinhado dos links */
                    }
                </style>
            </head>
            <body>
                <h1>Arquivos na Pasta: ${req.params.folder}</h1>
                <a href="/uploads">Voltar para o diretório principal</a>
                <ul>${fileLinks}</ul>
            </body>
            </html>
        `);
    });
});

// Rota para a página HTML
app.get('/', async (req, res) => {
    const ip = getLocalIP();
    const url = `http://${ip}:${port}/uploads`;
    const qrCodeDataUrl = await QRCode.toDataURL(url);
    
    const folderLinks = fs.readdirSync('uploads').filter(file => fs.statSync(path.join('uploads', file)).isDirectory());
    const folderCheckboxes = folderLinks.map(folder => `
        <input type="radio" name="targetFolder" value="${folder}" id="${folder}">
        <label for="${folder}">${folder}</label><br>
    `).join('');

    res.send(`
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Compartilhar Arquivos</title>
        </head>
        <body>
            <h1>Selecione os arquivos para enviar</h1>
            <form id="uploadForm" enctype="multipart/form-data">
                <input type="file" name="files" multiple required>
                <h2>Enviar para:</h2>
                ${folderCheckboxes}
                <button type="submit">Enviar</button>
            </form>
            <div id="message"></div>
            <h2>Acesse os arquivos em outros dispositivos:</h2>
            <img src="${qrCodeDataUrl}" alt="QR Code">
            <p>Escaneie o QR code para acessar os arquivos.</p>
            <p>Acesse diretamente: <a href="${url}">${url}</a></p>
            <h2>Área de Transferência de Texto Compartilhada</h2>
            <form id="textForm">
                <textarea name="sharedText" required></textarea>
                <button type="submit">Enviar</button>
            </form>
            <div id="sharedTexts">${sharedTexts.map(text => `
                <div>
                    <pre>${text}</pre>
                    <hr>
                </div>
            `).join('')}</div>
            <script>
                document.getElementById('uploadForm').onsubmit = async (e) => {
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const response = await fetch('/upload', {
                        method: 'POST',
                        body: formData
                    });
                    const message = await response.text();
                    document.getElementById('message').innerText = message;
                };

                document.getElementById('textForm').onsubmit = (e) => {
                    e.preventDefault();
                    const text = e.target.sharedText.value;
                    fetch('/addText', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ text })
                    }).then(response => response.text()).then(data => {
                        document.getElementById('sharedTexts').innerHTML = data;
                        e.target.reset();
                    });
                };
            </script>
        </body>
        </html>
    `);
});

// Rota para adicionar texto compartilhado
app.post('/addText', (req, res) => {
    const { text } = req.body;
    if (text) {
        sharedTexts.unshift(text); // Adiciona o novo texto no topo
    }
    res.send(sharedTexts.map(text => `
        <div>
            <pre>${text}</pre>
            <hr>
        </div>
    `).join(''));
});

// Função para obter o IP local
function getLocalIP() {
    const interfaces = os.networkInterfaces();
    for (const interface in interfaces) {
        for (const details of interfaces[interface]) {
            if (details.family === 'IPv4' && !details.internal) {
                return details.address;
            }
        }
    }
    return 'localhost';
}

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
